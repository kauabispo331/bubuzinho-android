# Bubuzinho — projeto para gerar APK

Jogo de bichinho virtual original, inspirado no gênero de pets virtuais. O progresso fica salvo no aparelho.

## Como gerar o APK no Android Studio

1. Instale o Android Studio no computador.
2. Abra a pasta `bubuzinho-apk` pelo menu **Open**.
3. Espere a sincronização do Gradle terminar.
4. Vá em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O Android Studio mostrará o botão para localizar o APK gerado.

O aplicativo não precisa de internet: o jogo está dentro de `app/src/main/assets/index.html`.
